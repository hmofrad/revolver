# 0.3.5 - 2014-09-22

* Giraph version updated to trunk:185205703ee4cd886598f5393395f19fc367f65f
* Implemented new triangle-related metrics.
* Added the Maximum B-Matching algorithm.


# 0.3.4 - 2014-07-09

* Giraph version updated to trunk:61cb37ecd50b0d9400873624e46692c3282e4cfc.
* Fix compatibility with latest Giraph.
* K-means clustering algorithm.
* Removed Yarn build since it's not being actively supported by Giraph.
